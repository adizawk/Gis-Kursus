<?php

class M_online extends CI_Model {

    public function simpan($data)
    {
        $this->db->insert('tbl_kursus', $data);
    }

    public function tampil()
    {
        $this->db->select('*');
        $this->db->from('tbl_kursus');
        $this->db->order_by('id_kursus', 'desc');
        return $this->db->get()->result();     
    }

    public function detail($id_kursus)
    {
        $this->db->select('*');
        $this->db->from('tbl_kursus');
        $this->db->where('id_kursus', $id_kursus); 
        return $this->db->get()->row();  
    }

    public function edit($data)
    {
        $this->db->where('id_kursus', $data['id_kursus']);
        $this->db->update('tbl_kursus', $data);
        
    }

    public function hapus($data)
    {
        $this->db->where('id_kursus', $data['id_kursus']);
        $this->db->delete('tbl_kursus', $data);
         
    }

}

/* End of file ModelName.php */
