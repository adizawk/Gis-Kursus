<div class="col-sm-7">
     <div class="panel panel-primary">
            <div class="panel-heading">
             Lokasi Sekolah
            </div>
            <div class="panel-body">
                
            <div id="mapid" style="height: 500px;"></div>
 
        </div>
    </div>
</div>



<div class="col-sm-5">
     <div class="panel panel-primary">
            <div class="panel-heading">
             Input Data
            </div>
            <div class="panel-body">
             <?php

            //validasi gagal upload
            if (isset($error_upload)) {
                echo '<div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>'.$error_upload.'</div>';
            }

            //validasi data tidak boleh kosong
            echo validation_errors('<div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>','</div>');

            //notifikasi pesan data berhasil disimpan

            if ($this->session->flashdata('pesan')) {
                echo '<div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
                echo $this->session->flashdata('pesan');
                echo '</div>';
            }

            echo form_open_multipart('sekolah/input'); 
            ?>

<div class="form-group">
    <label>Nama Pendaftar</label>
    <input name="nama" placeholder="Masukan Nama" value="<?= set_value('nama') ?>" class="form-control" />
</div>
                
<div class="form-group">
    <label>Asal Sekolah/Institusi</label>
    <input name="institusi" placeholder="Masukan Nama sekolah/Institusi" value="<?= set_value('institusi') ?>" class="form-control" />
</div>

<div class="mb-3">
    <!-- Tanggal Lahir : <input type="text" name="tgl" size="30" required><br><br> -->
    <!-- Tg : <input type="number" name="tg" min="1" max="31" value=”1”>
    Bl : <input type="number" name="bl" min="1" max="12" value=”1”>
    Th : <input type="number" name="th" min="2020" max="2030" ​​​value=”2020”><br><br>-->
        <label class="form-label">Tanggal Lahir : </label>
        <input type="date" name="tanggal_lahir">
</div>

<div class="form-group">
    <label>Alamat</label>
    <input name="alamat" placeholder="Masukan Alamat Lengkap" value="<?= set_value('alamat') ?>" class="form-control" />
</div>

<div class="form-group">
    <label>Jenis Kelamin</label>
    <select name="jenis_kelamin" class="form-control">
        <option value="">--Pilih Jenis Kelamin--</option>
        <option value="Laki">Laki-Laki</option>
        <option value="Perempuan">Perempuan</option>
    </select>
</div>

<div class="form-group">
    <label>No Telephone</label>
    <input name="no_telfon" placeholder="Masukan No Telephone" value="<?= set_value('no_telfon') ?>" class="form-control" />
</div>

<div class="form-group">
    <label>Email</label>
    <input name="email" placeholder="Masukan Email" value="<?= set_value('email') ?>" class="form-control" />
</div>

<div class="form-group">
    <label>Latitude</label>
    <input id="Latitude" name="latitude" placeholder="Latitude" value="<?= set_value('Latitude') ?>" class="form-control" readonly />
</div>

<div class="form-group">
    <label>Longitude</label>
    <input id="Longitude" name="longitude" placeholder="Longitude" value="<?= set_value('longitude') ?>" class="form-control" readonly />
</div>

<div class="form-group">
    <label>Gambar</label>
    <input type="file" name="gambar" class="form-control" required>
</div>

<div class="form-group">
    <label></label>
    <button type="submit" class="btn btn-sm btn-primary">Simpan</button>
    <button type="reset" class="btn btn-sm btn-success">Reset</button>
</div>


 <?php echo form_close(); ?>
        </div>
    </div>
</div>



<script>
var curLocation=[0,0];
if (curLocation[0]==0 && curLocation[1]==0) {
	curLocation =[-6.399444, 106.801658];	
}

var mymap = L.map('mapid').setView([-6.399444, 106.801658], 14);
L.tileLayer('https://api.mapbox.com/styles/v1/{id}/tiles/{z}/{x}/{y}?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, ' +
			'<a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
			'Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
			id: 'mapbox/streets-v11'
}).addTo(mymap);

mymap.attributionControl.setPrefix(false);
var marker = new L.marker(curLocation, {
	draggable:'true'
});

marker.on('dragend', function(event) {
var position = marker.getLatLng();
marker.setLatLng(position,{
	draggable : 'true'
	}).bindPopup(position).update();
	$("#Latitude").val(position.lat);
	$("#Longitude").val(position.lng).keyup();
});

$("#Latitude, #Longitude").change(function(){
	var position =[parseInt($("#Latitude").val()), parseInt($("#Longitude").val())];
	marker.setLatLng(position, {
	draggable : 'true'
	}).bindPopup(position).update();
	mymap.panTo(position);
});
mymap.addLayer(marker);

</script>