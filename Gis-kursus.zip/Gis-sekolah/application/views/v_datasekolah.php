<div class="col-sm-12">
<?php
    //notifikasi pesan databerhasil disimpan
     if ($this->session->flashdata('pesan')) {
        echo '<div class="alert alert-success alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>';
        echo $this->session->flashdata('pesan');
        echo '</div>';
    }
?>
    <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pendaftar</th>
                <th>Institusi</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Jenis Kelamin</th>
                <th>No Telephone</th>
                <th>Email</th>
                <?php if ($this->session->userdata('username')<>"") { ?>
                <th>Gambar</th>
                <th>Action</th>
                <?php } ?>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; foreach ($sekolah as $key => $value) { ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $value->nama ?></td>
                <td><?= $value->institusi ?></td>
                <td><?= $value->tanggal_lahir?></td>
                <td><?= $value->alamat ?></td>
                <td><?= $value->jenis_kelamin ?></td>
                <td><?= $value->no_telfon ?></td>
                <td><?= $value->email ?></td>
                <td><img src="<?= base_url('gambar/'. $value->gambar) ?>" width="100px"></td>
                <?php if ($this->session->userdata('username')<>"") { ?>
                <td>
                    <a href="<?= base_url('sekolah/edit/'.$value->id_kursus) ?>" class="btn btn-sm btn-warning">Edit</a>
                    <a href="<?= base_url('sekolah/hapus/'.$value->id_kursus) ?>" class="btn btn-sm btn-danger"
                    onClick="return confirm('Apakah data Ingin Dihapus...?')">Hapus</a>
                </td>
                <?php } ?>
            </tr>

             <?php } ?>
        </tbody>
    </table>

</div>