<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading"> List Kursus</div>
            <div class="panel-body">

            <table class="table table-responsive table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Pendaftar</th>
                <th>Institusi</th>
                <th>Tanggal Lahir</th>
                <th>Alamat</th>
                <th>Jenis Kelamin</th>
                <th>No Telephone</th>
                <th>Email</th>
                <?php if ($this->session->userdata('username')<>"") { ?>
                <th>Action</th>
                <?php } ?>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; foreach ($sekolah as $key => $value) { ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $value->nama ?></td>
                <td><?= $value->institusi ?></td>
                <td><?= $value->tanggal_lahir?></td>
                <td><?= $value->alamat ?></td>
                <td><?= $value->jenis_kelamin ?></td>
                <td><?= $value->no_telfon ?></td>
                <td><?= $value->email ?></td>
            </tr>

             <?php } ?>
        </tbody>
    </table>

                </div>
            </div>
        </div>
    </div>