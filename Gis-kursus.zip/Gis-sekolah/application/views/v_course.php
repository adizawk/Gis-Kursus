<div class="row">
    <div class="col-sm-12">
        <div class="panel panel-primary">
            <div class="panel-heading"> Course</div>
            <div class="panel-body">

                </div>
            </div>
        </div>
    </div>