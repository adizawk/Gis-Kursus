<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Webgis extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_online');
        
    }

    public function index()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'sekolah'   =>$this->m_online->tampil(),
            'isi'       => 'v_webgis'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }

    public function about()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'isi'       => 'v_about'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }

    public function list_kursus()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'sekolah'   =>$this->m_online->tampil(),
            'isi'       => 'v_list_kursus'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }

    public function course()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'isi'       => 'v_course'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }

    public function teacher()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'isi'       => 'v_teacher'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }

    public function contact()
    {
        $data = array(
            'title'     => 'Web GIS Kulon',
            'isi'       => 'v_contact'
        );
        $this->load->view('front-end/v_wrapper', $data, FALSE);
    }
}

/* webgisphp */
