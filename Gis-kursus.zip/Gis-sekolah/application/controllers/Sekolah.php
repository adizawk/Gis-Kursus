<?php

class Sekolah extends CI_Controller {

    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('m_online');
        
    }
    
    public function index()
    {
        $data = array(
            'title' => 'Data Kulon',
            'sekolah'=> $this->m_online->tampil(),
            'isi'   => 'v_datasekolah'
        );
        $this->load->view('layout/v_wrapper', $data, FALSE);     
    }

    public function input()
    {
        $this->user_login->cek_login();
        $this->form_validation->set_rules('nama', 'Nama Pendaftar', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('institusi', 'Asal Sekolah/Institusi', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('no_telfon', 'No Telephone', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('email', 'Email', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('latitude', 'Latitude', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('longitude', 'Longitude', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        
        
        if ($this->form_validation->run() == TRUE) {
            $config['upload_path']          = './gambar/';
            $config['allowed_types']        = 'gif|jpg|png|jpeg|icc';
            $config['max_size']             = 10000;
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('gambar')) {
                $data = array(
                    'title'         => 'Input Data Sekolah',
                    'error_upload'  =>$this->upload->display_errors(),
                    'isi'           => 'v_input_datasekolah'
                );
                $this->load->view('layout/v_wrapper', $data, FALSE);   
            }else{
                $upload_data = array('uploads' => $this->upload->data());
                $config['image_library'] = 'gd2';
                $config['source_image'] = './gambar/' .$upload_data['uploads']['file_name'];
                $this->load->library('image_lib', $config);
                $data = array(
                    'nama'           => $this->input->post('nama') , 
                    'institusi'      => $this->input->post('institusi') , 
                    'tanggal_lahir'  => $this->input->post('tanggal_lahir') , 
                    'alamat'         => $this->input->post('alamat') , 
                    'jenis_kelamin'  => $this->input->post('jenis_kelamin') , 
                    'no_telfon'      => $this->input->post('no_telfon') , 
                    'email'          => $this->input->post('email') , 
                    'latitude'       => $this->input->post('latitude') , 
                    'longitude'      => $this->input->post('longitude') , 
                    'gambar'         => $upload_data['uploads']['file_name'],
                 );
    $this->m_online->simpan($data);
    $this->session->set_flashdata('pesan', 'Data Berhasil Disimpan');
    redirect('sekolah/input');
            }
        }

        $data = array(
            'title'         => 'Input Data Sekolah',
            'isi'           => 'v_input_datasekolah'
        );
        $this->load->view('layout/v_wrapper', $data, FALSE);  

    }

    public function edit($id_kursus)
    {
        $this->user_login->cek_login();
        $this->form_validation->set_rules('nama', 'Nama Pendaftar', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('institusi', 'Asal Sekolah/Institusi', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('tanggal_lahir', 'Tanggal Lahir', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('alamat', 'Alamat', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis Kelamin', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('no_telfon', 'No Telephone', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('email', 'Email', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('latitude', 'Latitude', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));
        $this->form_validation->set_rules('longitude', 'Longitude', 'required',array(
            'required' => '%s Harus Diisi !!!'
        ));

        if ($this->form_validation->run() == FALSE) {
            $data = array(
                'title' => 'Edit Data Sekolah',
                'sekolah'=> $this->m_online->detail($id_kursus),
                'isi'   => 'v_edit_datasekolah'
            );
            $this->load->view('layout/v_wrapper', $data, FALSE);    

        }else{
            $data = array(
                            'id_kursus'      => $id_kursus,
                            'nama'           => $this->input->post('nama') , 
                            'institusi'      => $this->input->post('institusi') , 
                            'tanggal_lahir'  => $this->input->post('tanggal_lahir') , 
                            'alamat'         => $this->input->post('alamat') , 
                            'jenis_kelamin'  => $this->input->post('jenis_kelamin') , 
                            'no_telfon'      => $this->input->post('no_telfon') , 
                            'email'          => $this->input->post('email') , 
                            'latitude'       => $this->input->post('latitude') , 
                            'longitude'      => $this->input->post('longitude') , 
                );
            $this->m_online->simpan($data);
            $this->session->set_flashdata('pesan', 'Data Berhasil Diedit !!!');
            redirect('sekolah/input');
        }
    }

    public function hapus($id_kursus)
    {
        $this->user_login->cek_login();
        $data = array('id_kursus'=>$id_kursus);
        $this->m_online->hapus($data);
        $this->session->set_flashdata('pesan', 'Data Berhasil Dihapus !!!');
        redirect('sekolah');
    }

}

/* End of file Controllername.php */
